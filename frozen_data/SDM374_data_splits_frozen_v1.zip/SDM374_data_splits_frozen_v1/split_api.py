"""Dependency-free loader and verifier for the authoritative candidate-ID split lists."""
from pathlib import Path
from collections import Counter
import argparse
import csv
import hashlib
import json
import math

PROTOCOL_ID = "sdm374.same8.splits.2x5x3.frozen.v1"
DATA_SHA256 = "877b5f8ee265245dd693148a5d7b11f28f48b426e43ac3ac1be8b7a934249023"
WEIGHT_NAMES = ("cost", "carbon", "peak", "discomfort", "degradation", "ramping", "resilience")
WEIGHT_COLUMNS = [f"b{b}_{m}" for b in range(1, 4) for m in WEIGHT_NAMES]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_dataset(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        expected = {"candidate_id", "ramping", *WEIGHT_COLUMNS}
        require(len(reader.fieldnames or []) == 23 and set(reader.fieldnames) == expected,
                "Dataset columns differ from the 23-column contract")
        rows = list(reader)
    ids = [r["candidate_id"] for r in rows]
    require(all(ids) and len(set(ids)) == len(ids), "Missing or duplicate candidate_id")
    rows.sort(key=lambda r: r["candidate_id"])
    weights = [[float(r[f]) for f in WEIGHT_COLUMNS] for r in rows]
    values = [float(r["ramping"]) for r in rows]
    for w, recorded_value in zip(weights, values):
        require(all(math.isfinite(v) and v >= 0 for v in w), "Invalid input weights")
        require(all(abs(sum(w[b*7:(b+1)*7])-1) <= 1e-12 for b in range(3)), "Building weights must sum to 1")
        require(math.isfinite(recorded_value) and recorded_value >= 0, "Invalid ramping value")
    require(len(set(tuple(w) for w in weights)) == len(weights), "Duplicate weight vectors need a new grouped-split protocol")
    records = [dict(candidate_id=r["candidate_id"], **dict(zip(WEIGHT_COLUMNS,w)), ramping=v)
               for r,w,v in zip(rows,weights,values)]
    return dict(candidate_ids=[r["candidate_id"] for r in rows], columns=["candidate_id",*WEIGHT_COLUMNS,"ramping"], records=records)


def membership_sha256(manifest):
    identity = {"data_sha256":manifest["dataset"]["sha256"],
                "canonical_candidate_ids":manifest["canonical_candidate_ids"],
                "outer_splits":manifest["outer_splits"]}
    encoded = json.dumps(identity,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def check_partition(train_ids, valid_ids, universe, context):
    require(len(train_ids) == len(set(train_ids)), f"{context}: duplicate training IDs")
    require(len(valid_ids) == len(set(valid_ids)), f"{context}: duplicate held-out IDs")
    train, valid = set(train_ids), set(valid_ids)
    require(train and valid, f"{context}: empty partition")
    require(not train.intersection(valid), f"{context}: training/held-out leakage")
    require(train.union(valid) == set(universe), f"{context}: missing or extra IDs")
    require(train_ids == sorted(train_ids) and valid_ids == sorted(valid_ids), f"{context}: lists must use canonical ID order")


def validate_manifest(manifest, candidate_ids):
    require(manifest["protocol_id"] == PROTOCOL_ID, "Unknown protocol version")
    require(manifest["index_base"] == 0, "Expected zero-based fold indexes")
    require(manifest["status"] == "FROZEN", "Expected frozen release")
    require(manifest["dataset"]["weight_columns"] == WEIGHT_COLUMNS, "Column order mismatch")
    require(manifest["dataset"]["sha256"] == DATA_SHA256, "Wrong dataset version")
    require(manifest["canonical_candidate_ids"] == sorted(candidate_ids), "Canonical ID list mismatch")
    require(len(candidate_ids) == 2048, "This version requires exactly 2048 candidates")
    outer = manifest["outer_splits"]
    require(len(outer) == 10, "Expected 10 outer splits")
    require(len({r["split_id"] for r in outer}) == 10, "Duplicate split_id")
    require({(r["repeat_index"], r["fold_index"]) for r in outer} == {(a,b) for a in range(2) for b in range(5)}, "Outer index coverage mismatch")
    test_counts = {r: Counter() for r in range(2)}
    total_inner = 0
    for row in outer:
        context = row["split_id"]
        rep, fold = row["repeat_index"], row["fold_index"]
        require(context == f"r{rep+1:02d}_f{fold+1:02d}", "Human-readable split_id mismatch")
        require(row["inner_seed"] == 20261024 + rep*5 + fold + 1, "Inner seed metadata mismatch")
        tr, te = row["outer_train_ids"], row["outer_test_ids"]
        check_partition(tr, te, candidate_ids, context)
        require(len(te) == (410 if fold < 3 else 409), f"{context}: test size mismatch")
        test_counts[rep].update(te)
        inner = row["inner_splits"]
        require(len(inner) == 3 and {r["inner_fold_index"] for r in inner} == {0,1,2}, f"{context}: invalid inner fold indexes")
        validation_counts = Counter()
        for part in inner:
            it, iv = part["inner_train_ids"], part["inner_validation_ids"]
            check_partition(it, iv, tr, context + "/inner")
            require(not set(it+iv).intersection(te), f"{context}: outer test entered inner CV")
            j = part["inner_fold_index"]
            expected = len(tr)//3 + int(j < len(tr)%3)
            require(len(iv) == expected, f"{context}: inner validation size mismatch")
            validation_counts.update(iv)
            total_inner += 1
        require(validation_counts == Counter({i:1 for i in tr}), f"{context}: each outer-train ID must validate once internally")
    for rep in range(2):
        require(test_counts[rep] == Counter({i:1 for i in candidate_ids}), f"Repeat {rep}: each candidate must be tested once")
    return dict(status="passed", protocol_id=PROTOCOL_ID, candidates=2048,
                repeats=2, outer_splits=10, inner_splits=total_inner,
                outer_test_sizes=[409,410], inner_validation_sizes=[546,547])


def load_package(package_dir=None, verify_checksums=True):
    root = Path(package_dir) if package_dir else Path(__file__).resolve().parent
    manifest = json.loads((root/"split_manifest.json").read_text(encoding="utf-8"))
    release = json.loads((root/"RELEASE.json").read_text(encoding="utf-8"))
    require(release["status"] == "FROZEN" and release["protocol_id"] == PROTOCOL_ID, "Release identity mismatch")
    require(sha256(root/"split_manifest.json") == release["manifest_sha256"], "Frozen manifest changed")
    require(membership_sha256(manifest) == release["split_membership_sha256"], "Frozen split membership changed")
    if verify_checksums:
        checksums = json.loads((root/"checksums.json").read_text(encoding="utf-8"))
        for relative, digest in checksums["files"].items():
            path = (root/relative).resolve()
            require(path.is_relative_to(root.resolve()), "Checksum path escapes package")
            require(sha256(path) == digest, f"File checksum mismatch: {relative}")
    path = root/manifest["dataset"]["relative_path"]
    require(sha256(path) == manifest["dataset"]["sha256"], "Dataset SHA256 mismatch; do not silently resplit")
    dataset = read_dataset(path)
    validate_manifest(manifest, dataset["candidate_ids"])
    return dataset, manifest


def iter_nested_splits(manifest, candidate_ids):
    """Outer positions index all records; inner positions index the outer-train subset."""
    require(len(candidate_ids) == len(set(candidate_ids)), "Duplicate IDs in caller's array")
    require(set(candidate_ids) == set(manifest["canonical_candidate_ids"]), "Caller ID universe mismatch")
    positions = {value:i for i,value in enumerate(candidate_ids)}
    for row in manifest["outer_splits"]:
        tr = [positions[i] for i in row["outer_train_ids"]]
        te = [positions[i] for i in row["outer_test_ids"]]
        relative = {value:i for i,value in enumerate(row["outer_train_ids"])}
        inner = [([relative[i] for i in part["inner_train_ids"]],
                  [relative[i] for i in part["inner_validation_ids"]]) for part in row["inner_splits"]]
        yield dict(split_id=row["split_id"], repeat_index=row["repeat_index"],
                   fold_index=row["fold_index"], outer_train=tr, outer_test=te, inner_cv=inner)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    dataset, manifest = load_package(args.package_dir)
    print(json.dumps(validate_manifest(manifest, dataset["candidate_ids"]), indent=2))
