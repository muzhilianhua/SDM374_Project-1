"""Reproduce all stored partitions in memory; never rewrite the frozen files."""
import numpy as np
import sklearn
from sklearn.model_selection import RepeatedKFold,KFold
from split_api import load_package,iter_nested_splits


def main():
    if np.__version__!="1.26.4" or sklearn.__version__!="1.5.2":
        raise RuntimeError("Use numpy==1.26.4 and scikit-learn==1.5.2 for canonical reproduction, or read the stored IDs directly.")
    data,manifest=load_package()
    ids=data["candidate_ids"]
    stored=list(iter_nested_splits(manifest,ids))
    for index,((tr,te),row) in enumerate(zip(RepeatedKFold(n_splits=5,n_repeats=2,random_state=20261024).split(ids),stored)):
        tr,te=np.sort(tr),np.sort(te)
        np.testing.assert_array_equal(tr,row["outer_train"])
        np.testing.assert_array_equal(te,row["outer_test"])
        for (it,iv),(st,sv) in zip(KFold(n_splits=3,shuffle=True,random_state=20261024+index+1).split(tr),row["inner_cv"]):
            np.testing.assert_array_equal(it,st)
            np.testing.assert_array_equal(iv,sv)
    print("PASS: all 10 outer partitions and 30 inner partitions reproduced exactly; no files rewritten.")


if __name__=="__main__":main()
