# SDM374 数据统一划分：冻结版 v1

协议编号：`sdm374.same8.splits.2x5x3.frozen.v1`  
冻结日期：2026-10-25  
状态：`FROZEN`

本包只固定原始数据、样本编号、内外层分区及读取校验方式。其他研究约定由独立文件管理，不属于本包。

## 给使用者的说明

### 固定了什么

- 一份原始数据：2048条、23列，文件内容逐字节保留。
- 两次重复，每次五个外层折，共十组外层分区。
- 每组外层训练部分再分三个内层折，共三十组内层分区。
- 每条记录在每组分区中的角色，由明确的 `candidate_id` 清单决定。
- 读取顺序、索引含义、完整性校验和原始生成机制。

各分区成员沿用最初确认的清单。本次发布不重新抽样。

### 怎样理解内外层

以 `r01_f01` 为例：它表示第一次重复、第一外层折。

```text
完整数据：2048条
  ├─ outer_train：1638条
  │      └─ 三组内层分区
  │             每组 inner_train：1092条
  │             每组 inner_validation：546条
  └─ outer_test：410条
```

同一组外层分区中，`outer_train` 与 `outer_test` 不重叠。

每个内层折完全位于其所属的 `outer_train` 中，`inner_train` 与 `inner_validation` 不重叠，也都不包含该组 `outer_test` 的记录。

同一次重复的五个外层折中，每条记录恰好属于一个 `outer_test`，并属于其他四个 `outer_train`。两次重复使用同一批记录，不会增加新的独立记录。

### 各分区的数量

| 部分 | 数量 |
| --- | ---: |
| 原始记录 | 2048 |
| 每组 outer_train | 1638或1639 |
| 每组 outer_test | 409或410 |
| 每组 inner_train | 1092或1093 |
| 每组 inner_validation | 546或547 |

这是随机、数量均衡的分区。没有按 `ramping` 数值分层，也没有按该字段筛选记录。“均衡”指每折条数相差至多一条，不表示每折的数值分布完全相同。

### 最常用的文件

| 文件 | 作用 |
| --- | --- |
| `data/train.csv` | 原始数据 |
| `split_manifest.json` | 权威清单：逐组列出所有内外层记录编号 |
| `outer_assignments.csv` | 查阅某编号在每次重复中属于哪个外层测试折 |
| `inner_assignments.csv` | 查阅外层训练编号属于哪个内层验证折 |
| `fold_sizes.csv` | 查阅各组分区的样本数量 |
| `split_api.py` | 无第三方依赖的读取、索引转换和校验代码 |
| `verify_reproduction.py` | 在内存中核对原始生成算法，不改写任何文件 |
| `requirements-reproduce.txt` | 仅用于可选的算法复现核对 |
| `RELEASE.json` | 冻结身份、数据摘要、分区成员摘要和清单摘要 |
| `checksums.json` | 包内文件的SHA256摘要 |
| `verification.json` | 发布前的分区完整性核对记录 |
| `README.md` | 人工说明、程序规则和AI交接提示词 |

`train.csv` 是原文件名。它存放完整2048条记录，不代表整个文件总是属于某组 `outer_train`。每组成员以清单为准。

### 怎样开始使用

解压后进入包目录，执行：

```bash
python split_api.py
```

Python 3.9及以上即可，不需要安装第三方库。正常输出含 `"status": "passed"`、2048条记录、10组外层和30组内层分区。

你可以直接把ZIP发给另一位组员。ZIP外另附同一份README，以及用于核对交付文件的 `SHA256SUMS.txt`。

## 给程序与AI的规则

### 权威与冻结约定

1. `split_manifest.json` 中明确列出的ID是权威。不得用另一套随机抽样取代。
2. `RELEASE.json` 绑定原始数据、分区成员和清单内容；`checksums.json` 绑定包内文件。
3. 使用者不得改写本冻结版的任何文件。所有附加研究文件放在包目录之外。
4. 同一数据和这套固定分区可以一直使用，不依赖后续研究约定。
5. 如原始记录或分区成员确需改变，另建新的协议编号与发布包，不覆盖本版，不沿用本版摘要。
6. 检查不通过时停止并报告，不自动修补、删行或重分。

### 数据与编号

- 原始文件SHA256：`877b5f8ee265245dd693148a5d7b11f28f48b426e43ac3ac1be8b7a934249023`。
- 唯一记录编号列：`candidate_id`。
- 原表还包含三栋楼各七列权重，以及一个 `ramping` 记录字段。
- 权重列按楼宇1、2、3排列；每栋楼依次为 `cost, carbon, peak, discomfort, degradation, ramping, resilience`。完整列名见清单的 `dataset.weight_columns`。
- 规范顺序为 `candidate_id` 字典序升序。记录编号不是数值字段。
- JSON与CSV均为UTF-8。所有 `*_index` 从0开始；`r01_f01` 等可读名称从1开始。
- 包内数据文件不得重新保存。读入内存后的记录顺序可以变化，但必须保留同步的ID，并重新按ID映射位置。

### 原始生成机制

以下内容用于核对来源，不替代现成ID清单：

```json
{
  "canonical_order": "candidate_id ascending lexical order",
  "index_base": 0,
  "outer": {
    "algorithm": "RepeatedKFold",
    "n_splits": 5,
    "n_repeats": 2,
    "random_state": 20261024
  },
  "inner": {
    "algorithm": "KFold",
    "n_splits": 3,
    "shuffle": true,
    "random_state": "20261024 + repeat_index*5 + fold_index + 1"
  },
  "generation_environment": {
    "numpy": "1.26.4",
    "scikit_learn": "1.5.2"
  },
  "stratified": false
}
```

生成外层分区后，将其位置分别升序排列，再映射成ID。内层算法的输入是当前 `outer_train_ids` 的规范顺序，内层位置相对于该列表。

种子是整数，不按日期运算。不必为了读取现有清单改变工作环境。只有需要核对原始算法时，才使用固定依赖：

```bash
python -m pip install -r requirements-reproduce.txt
python verify_reproduction.py
```

该命令只在内存中重新计算并比较，不修改冻结文件。

### 推荐读取示例

```python
from pathlib import Path
from split_api import load_package, iter_nested_splits

package_root = Path(__file__).resolve().parent
table, manifest = load_package(package_root)
records = table["records"]

for part in iter_nested_splits(manifest, table["candidate_ids"]):
    outer_train = [records[i] for i in part["outer_train"]]
    outer_test = [records[i] for i in part["outer_test"]]

    for inner_train_positions, inner_validation_positions in part["inner_cv"]:
        # 内层位置相对于outer_train，不是相对于完整records。
        inner_train = [outer_train[i] for i in inner_train_positions]
        inner_validation = [outer_train[i] for i in inner_validation_positions]
        # 此处只取得清单指定的记录。
```

Notebook中没有 `__file__` 时，请把 `package_root` 明确设置为解压后的包目录。

### 必须满足的分区不变量

- 每组外层的两个集合无交集，合并后恰好是完整2048个ID。
- 每次重复中，五个外层测试集合不重叠，合并后恰好是完整ID集合。
- 每组内层的两个集合无交集，合并后恰好是其所属的外层训练ID集合。
- 每组外层内部，三个内层验证集合不重叠，合并后恰好是外层训练ID集合。
- 外层测试ID不出现在该组的任一内层集合中。
- ID不能缺失、重复或超出原始数据范围。

## 给下一位AI的提示词

复制以下内容，并附上本ZIP：

```text
请读取SDM374_data_splits_frozen_v1包，完成统一数据分区的加载与核对。

协议编号为sdm374.same8.splits.2x5x3.frozen.v1，状态FROZEN。只以包内原始数据和精确ID清单为依据，不依赖先前聊天记录。

先阅读README.md、RELEASE.json、split_manifest.json，运行python split_api.py，确认文件摘要及分区完整性检查通过。数据为data/train.csv，共2048条、23列；其SHA256必须为877b5f8ee265245dd693148a5d7b11f28f48b426e43ac3ac1be8b7a934249023。candidate_id是唯一记录编号。

通过load_package()读取记录，通过iter_nested_splits()读取十组外层及每组对应的三组内层位置。outer_train和outer_test位置索引完整records；inner_cv中的位置索引当前outer_train。所有*_index从0开始，可读名称r01_f01从1开始。保留ID与记录位置的同步关系，不能只凭CSV行号猜测分区。

禁止重新随机划分、按ramping分层、添加任何按数值筛选的分组、删除记录、修改种子、重写清单或改写包内文件。其他研究约定不属于本包，不能根据本包自行推导；等待用户单独指定。附加文件写在包目录之外。

核对每组外层两侧无重叠且并集为全部ID；每个内层完全位于所属外层训练集合中，两侧无重叠；外层测试ID不进入该组内层；每次重复五个外层测试集合完整覆盖全部ID一次；每组外层内部三个内层验证集合完整覆盖其外层训练ID一次。

如需核对算法来源，可在指定依赖环境中运行verify_reproduction.py；该脚本只在内存中重建并比较，不会改写文件。清单ID优先于任何重新生成的随机结果。

若摘要、ID或分区不变量不一致，停止并报告，不擅自修补。此冻结版不得覆盖更新；若用户另行要求不同数据或不同分区，应创建独立版本和新协议编号，保留本版原样。
```
