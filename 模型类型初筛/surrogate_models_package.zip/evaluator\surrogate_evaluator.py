"""代理模型评估器：专门评估"模型是否适合用来做参数寻优"。

四个核心维度：
1. 最优 5% 局部精度（MAE / RMSE / R2 / 偏差方向）
2. 排名一致性（Spearman 秩相关）
3. 多模型最优解对比（收敛性）
4. 子集模拟寻优（模型在 holdout 上挑出的 Top-K 真实排第几）

用法示例：
    from surrogate_evaluator import SurrogateEvaluator
    ev = SurrogateEvaluator(X, y, feature_names=FEATURES)
    report = ev.evaluate(model, model_name="GBDT")
    print(report.summary())
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold
from dataclasses import dataclass, field
from typing import Any, Callable


# ──────────────────────────────────────────────
# 数据结构
# ──────────────────────────────────────────────
@dataclass
class LocalMetrics:
    """最优区域局部指标。"""
    threshold: float          # 划分阈值（y 的 5% 分位）
    n_good: int               # 落入最优区域的样本数
    mae: float
    rmse: float
    r2: float
    bias: float               # mean(pred - true)，正=模型保守（把好解说差），负=模型乐观（把差解说好）
    mae_overall: float        # 全样本 MAE，做对比用

    @property
    def pass_mae(self) -> bool:
        """局部 MAE 是否在整体 MAE 的 1.5 倍以内。"""
        return self.mae <= self.mae_overall * 1.5

    @property
    def pass_bias(self) -> bool:
        """偏差是否可接受：不允许低估好解（bias < -3 视为模型乐观）。"""
        return self.bias >= -3.0


@dataclass
class RankingResult:
    """排名一致性。"""
    spearman_r: float
    spearman_p: float

    @property
    def pass_ranking(self) -> bool:
        return self.spearman_r >= 0.6


@dataclass
class SubsetOptResult:
    """子集模拟寻优结果。"""
    fold: int
    n_holdout: int
    k: int                     # 挑 Top-K
    best_true_rank: int        # 模型挑的 Top-K 里，最好的那个在 holdout 里排第几（0=最好）
    mean_true_percentile: float # Top-K 真实分位数均值（0=全部最好，1=全部最差）
    best_true_value: float     # Top-K 里真实 ramping 最低值
    holdout_best_value: float  # holdout 里真实最低值
    gap: float                 # best_true_value - holdout_best_value

    @property
    def pass_topk(self) -> bool:
        """Top-K 平均分位是否进入前 10%。"""
        return self.mean_true_percentile <= 0.10


@dataclass
class ModelReport:
    model_name: str
    local: LocalMetrics
    ranking: RankingResult
    subset_runs: list[SubsetOptResult] = field(default_factory=list)

    @property
    def subset_pass_count(self) -> int:
        return sum(1 for r in self.subset_runs if r.pass_topk)

    @property
    def subset_pass_rate(self) -> float:
        if not self.subset_runs:
            return 0.0
        return self.subset_pass_count / len(self.subset_runs)

    @property
    def verdict(self) -> str:
        """综合判定：模型能不能用来寻优。"""
        checks = [
            self.local.pass_mae,
            self.local.pass_bias,
            self.ranking.pass_ranking,
            self.subset_pass_rate >= 0.6,
        ]
        n_pass = sum(checks)
        if n_pass == 4:
            return "✅ 推荐使用：模型在寻优场景下可靠"
        elif n_pass >= 3:
            return "⚠️ 基本可用：注意保守选点，别选最极端的解"
        else:
            return "❌ 不推荐：模型在好解区域不可靠，建议回退到已知最优解附近搜索"

    def summary(self) -> str:
        lines = [
            f"{'='*50}",
            f"模型：{self.model_name}",
            f"{'='*50}",
            f"",
            f"【1. 最优 5% 局部精度】（阈值={self.local.threshold:.2f}, n={self.local.n_good}）",
            f"  MAE={self.local.mae:.2f}  RMSE={self.local.rmse:.2f}  R²={self.local.r2:.3f}",
            f"  偏差={self.local.bias:+.2f}  "
            f"{'(模型乐观⚠️ 低估好解)' if self.local.bias < -3 else '(保守/正常)'}",
            f"  全样本 MAE={self.local.mae_overall:.2f}  局部/整体={self.local.mae/max(self.local.mae_overall,0.01):.2f}x",
            f"  {'✅ 通过' if self.local.pass_mae else '⚠️ 局部MAE偏大'}",
            f"",
            f"【2. 排名一致性】",
            f"  Spearman ρ={self.ranking.spearman_r:.3f}  (p={self.ranking.spearman_p:.2e})",
            f"  {'✅ 通过' if self.ranking.pass_ranking else '⚠️ 排序不够可靠'}",
            f"",
            f"【3. 子集模拟寻优】（{len(self.subset_runs)} 折）",
        ]
        for r in self.subset_runs:
            lines.append(
                f"  折{r.fold}: Top-{r.k} 平均分位={r.mean_true_percentile*100:.1f}%, "
                f"最优值={r.best_true_value:.1f} (全局最优={r.holdout_best_value:.1f}, gap={r.gap:+.1f})"
            )
        lines.append(f"  通过率：{self.subset_pass_count}/{len(self.subset_runs)} ({self.subset_pass_rate*100:.0f}%)")
        lines.append(f"")
        lines.append(f"综合判定：{self.verdict}")
        return "\n".join(lines)


# ──────────────────────────────────────────────
# 评估器主体
# ──────────────────────────────────────────────
class SurrogateEvaluator:
    """代理模型寻优适用性评估器。

    Parameters
    ----------
    X : np.ndarray, shape (n, 21)
        训练特征（原始权重，每栋楼7项和为1）。
    y : np.ndarray, shape (n,)
        目标值 ramping（越小越好）。
    feature_names : list[str], optional
        21 个特征名，用于多模型对比时输出最优解。
    """

    def __init__(self, X: np.ndarray, y: np.ndarray, feature_names: list[str] | None = None):
        self.X = np.asarray(X, dtype=float)
        self.y = np.asarray(y, dtype=float)
        self.feature_names = feature_names
        self._good_threshold = float(np.percentile(self.y, 5))  # 最优 5% 阈值

    # ── 1. 最优区域局部精度 ──
    def evaluate_local(self, y_pred: np.ndarray) -> LocalMetrics:
        mask = self.y <= self._good_threshold
        y_good = self.y[mask]
        p_good = y_pred[mask]
        return LocalMetrics(
            threshold=self._good_threshold,
            n_good=int(mask.sum()),
            mae=float(mean_absolute_error(y_good, p_good)),
            rmse=float(np.sqrt(mean_squared_error(y_good, p_good))),
            r2=float(r2_score(y_good, p_good)),
            bias=float(np.mean(p_good - y_good)),
            mae_overall=float(mean_absolute_error(self.y, y_pred)),
        )

    # ── 2. 排名一致性 ──
    def evaluate_ranking(self, y_pred: np.ndarray) -> RankingResult:
        rho, pval = spearmanr(self.y, y_pred)
        return RankingResult(spearman_r=float(rho), spearman_p=float(pval))

    # ── 3. 子集模拟寻优 ──
    def subset_optimization(
        self,
        model_factory: Callable[[], Any],
        n_folds: int = 3,
        top_k: int = 10,
        search_n: int = 50000,
        random_state: int = 2026,
    ) -> list[SubsetOptResult]:
        """模拟"用模型在 holdout 里挑最优解"的过程。

        每折：
          1. 切 train/holdout
          2. 在 train 上训练模型
          3. 直接在 holdout 的 X 上预测，挑预测最低的 Top-K
          4. 看这 Top-K 在 holdout 真实 y 里排第几

        Parameters
        ----------
        model_factory : callable
            零参数函数，返回一个新的未训练模型实例（必须有 .fit 和 .predict）。
        n_folds : int
            重复几次切分。
        top_k : int
            每次挑预测最低的前 K 个。
        search_n : int
            不直接搜整个空间，而是在 holdout 的 X 上预测（因为 holdout 里的点
            我们知道真实值，相当于把 holdout 当作候选池）。
        """
        results = []
        kf = KFold(n_splits=n_folds, shuffle=True, random_state=random_state)
        for fold_idx, (train_idx, holdout_idx) in enumerate(kf.split(self.X)):
            X_tr, y_tr = self.X[train_idx], self.y[train_idx]
            X_ho, y_ho = self.X[holdout_idx], self.y[holdout_idx]

            model = model_factory()
            model.fit(X_tr, y_tr)
            pred_ho = model.predict(X_ho)

            # 模型挑预测最低的 Top-K
            topk_idx = np.argsort(pred_ho)[:top_k]
            topk_true = y_ho[topk_idx]

            # 这些点在 holdout 真实排名里的位置
            sorted_true = np.sort(y_ho)
            best_val = float(topk_true.min())
            best_rank = int(np.searchsorted(sorted_true, best_val))

            # 每个 Top-K 点的真实分位
            ranks = np.array([np.searchsorted(sorted_true, v) / len(y_ho) for v in topk_true])

            results.append(SubsetOptResult(
                fold=fold_idx + 1,
                n_holdout=len(y_ho),
                k=top_k,
                best_true_rank=best_rank,
                mean_true_percentile=float(ranks.mean()),
                best_true_value=best_val,
                holdout_best_value=float(y_ho.min()),
                gap=best_val - float(y_ho.min()),
            ))
        return results

    # ── 综合评估 ──
    def evaluate(
        self,
        model: Any,
        model_name: str = "model",
        oof_predictions: np.ndarray | None = None,
        run_subset: bool = True,
        model_factory: Callable[[], Any] | None = None,
        subset_folds: int = 3,
        subset_topk: int = 10,
    ) -> ModelReport:
        """完整评估一个模型。

        Parameters
        ----------
        model :
            已训练好的模型。用于计算局部精度和排名一致性。
        model_name : str
            模型名称。
        oof_predictions : np.ndarray, optional
            如果已经有 5 折 OOF 预测，直接传入；否则用 model.predict(X)（会偏乐观）。
        run_subset : bool
            是否跑子集模拟寻优。
        model_factory : callable, optional
            用于子集模拟的模型工厂。如果 run_subset=True 且未提供，用 model 本身深拷贝。
        """
        if oof_predictions is not None:
            y_pred = np.asarray(oof_predictions)
        else:
            y_pred = model.predict(self.X)

        local = self.evaluate_local(y_pred)
        ranking = self.evaluate_ranking(y_pred)

        subset_runs = []
        if run_subset:
            factory = model_factory or (lambda: _DummyModel(model))
            subset_runs = self.subset_optimization(factory, n_folds=subset_folds, top_k=subset_topk)

        return ModelReport(
            model_name=model_name,
            local=local,
            ranking=ranking,
            subset_runs=subset_runs,
        )

    # ── 4. 多模型对比 ──
    @staticmethod
    def compare_models(reports: list[ModelReport]) -> pd.DataFrame:
        """把多个模型的报告汇总成一张对比表。"""
        rows = []
        for r in reports:
            rows.append({
                "模型": r.model_name,
                "整体MAE": f"{r.local.mae_overall:.2f}",
                "最优5% MAE": f"{r.local.mae:.2f}",
                "偏差": f"{r.local.bias:+.2f}",
                "Spearman ρ": f"{r.ranking.spearman_r:.3f}",
                "子集通过率": f"{r.subset_pass_rate*100:.0f}%",
                "判定": r.verdict,
            })
        return pd.DataFrame(rows)


class _DummyModel:
    """包装已训练模型，假装它能 fit（fit 时不做事）。"""
    def __init__(self, model):
        self._m = model
    def fit(self, X, y):
        return self
    def predict(self, X):
        return self._m.predict(X)


# ──────────────────────────────────────────────
# 快速演示
# ──────────────────────────────────────────────
if __name__ == "__main__":
    from pathlib import Path
    import sys

    # 自动找 train.csv
    candidates = [
        Path("Lab6/dataset_same8/train.csv"),
        Path("dataset_same8/train.csv"),
        Path(__file__).parent / "dataset_same8" / "train.csv",
    ]
    train_path = next((p for p in candidates if p.exists()), None)
    if train_path is None:
        print("找不到 train.csv，请手动指定路径")
        sys.exit(1)

    METRICS = ("cost", "carbon", "peak", "discomfort", "degradation", "ramping", "resilience")
    FEATURES = [f"b{building}_{metric}" for building in range(1, 4) for metric in METRICS]

    df = pd.read_csv(train_path)
    X = df[FEATURES].to_numpy()
    y = df["ramping"].to_numpy()
    print(f"加载数据：{X.shape[0]} 条，{X.shape[1]} 维特征")

    ev = SurrogateEvaluator(X, y, feature_names=FEATURES)

    # 用 GBDT 做演示
    from lightgbm import LGBMRegressor
    from sklearn.model_selection import cross_val_predict

    model = LGBMRegressor(n_estimators=300, learning_rate=0.05, num_leaves=15, verbose=-1)
    oof = cross_val_predict(model, X, y, cv=5, method="predict")
    model.fit(X, y)

    report = ev.evaluate(
        model,
        model_name="LightGBM",
        oof_predictions=oof,
        run_subset=True,
        model_factory=lambda: LGBMRegressor(n_estimators=300, learning_rate=0.05, num_leaves=15, verbose=-1),
        subset_folds=3,
        subset_topk=10,
    )
    print(report.summary())
