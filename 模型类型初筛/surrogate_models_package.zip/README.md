# SDM374 代理模型评估交付包

**交付目的**：将本项目中已测试的全部代理模型（代码 + 结论 + 文档）整理为一个自包含交付物，供第三方（人或 AI）独立复现并评估。

**打包日期**：2026-10-24
**项目**：SDM374 数据驱动楼宇能量管理 · 代理模型选型

---

## 1. 包结构

```
surrogate_models_package/
├── README.md                              # 本文件
├── REPRODUCE.md                           # 复现步骤详细说明
├── requirements.txt                       # Python 依赖清单
│
├── data/                                  # 训练数据（2048 条 × 23 列）
│   ├── train.csv                          # 唯一训练表
│   ├── README.md                          # 数据说明（重要）
│   └── manifest.json                      # 数据版本 + SHA256
│
├── evaluator/
│   └── surrogate_evaluator.py             # Lab6 官方评估器（评估协议）
│
├── models/                                # 9 个被评估模型的独立训练脚本
│   ├── ridge_regression_strat82.py        # ① 二次岭回归 (deg=2)
│   ├── xgb_regression_strat82.py          # ② XGBoost 原始 21 维
│   ├── xgb_alr_clr_strat82.py             # ③④ XGBoost + ALR (18d) / CLR (21d)
│   ├── histgb_regression_strat82.py       # ⑤ HistGradientBoosting
│   ├── rf_regression.py                   # ⑥a 随机森林 (全样本)
│   ├── rf_regression_low50.py             # ⑥b 随机森林 (仅用 ramping 较低 50% 样本)
│   ├── gam_regression_strat82.py          # ⑦ Bayesian GAM (P-spline Gibbs)
│   ├── bart_regression_strat82.py         # ⑧ BART (50 树 MCMC)
│   ├── spmm_regression.py                 # ⑨ SPMM 半参数混合 (Ridge + RBF-KRR)
│   └── variants/                          # 后续改进变体（不在主表内）
│       ├── xgb_conformal_strat82.py       # XGB + 距离分层 Mondrian Conformal
│       └── xgb_top5_weighted_strat82.py   # XGB + 最优 5% 样本加权 (×8)
│
├── report/                                # 主结论（要看的就是这里）
│   ├── surrogate_model_report.ipynb       # 综合评估 Jupyter 报告（自包含、可重跑）
│   └── surrogate_eval_metrics.csv         # 9 个模型最终指标对比表
│
└── figures/                               # 各模型拟合曲线 PNG
    ├── ridge_fit_curves_strat82.png
    ├── xgb_fit_curves_strat82.png
    ├── xgb_alr_clr_fit_curves.png
    ├── histgb_fit_curves_strat82.png
    ├── rf_fit_curves.png
    ├── rf_fit_curves_low50.png
    ├── gam_fit_curves_strat82.png
    ├── bart_fit_curves_strat82.png
    ├── spmm_fit_curves.png
    └── xgb_fit_curves_top5w.png
```

---

## 2. 一句话结论

按 `通过检查数 → 子集通过率 → Top-K 平均真实分位 → 最优 5% MAE` 排序，9 个模型的最终排名与判定：

| 排名 | 模型 | 整体 MAE | 最优 5% MAE | Spearman ρ | 通过检查数 | 判定 |
|---|---|---|---|---|---|---|
| 1 | **XGBoost (原始 21 维)** | 4.63 | 6.90 | 0.907 | 4/4 | ✅ 推荐 |
| 2 | **HistGradientBoosting** | 4.76 | 6.92 | 0.901 | 4/4 | ✅ 推荐 |
| 3 | **SPMM 半参数混合** | 6.00 | 8.45 | 0.857 | 4/4 | ✅ 推荐 |
| 4 | XGBoost + CLR (21 维) | 5.40 | 9.60 | 0.884 | 3/4 | ⚠️ 基本可用 |
| 5 | 随机森林 RF(800) | 5.55 | 9.62 | 0.867 | 3/4 | ⚠️ 基本可用 |
| 6 | BART (50 树) | 6.69 | 12.97 | 0.827 | 3/4 | ⚠️ 基本可用 |
| 7 | XGBoost + ALR (18 维) | 6.80 | 13.80 | 0.806 | 3/4 | ⚠️ 基本可用 |
| 8 | 二次岭回归 Ridge(deg=2) | 6.76 | 11.91 | 0.842 | 3/4 | ⚠️ 基本可用 |
| 9 | 贝叶斯 GAM (P-spline) | 6.58 | 10.08 | 0.838 | 3/4 | ⚠️ 基本可用 |

**推荐策略**：XGBoost（原始 21 维）作为主代理模型，HistGB / SPMM 作为交叉验证备份；所有模型在最优 5% 区域都"保守"（偏差 +6 ~ +14），无低估好解风险；成分变换（ALR/CLR）在本任务上**未带来增益**，建议保持原始 21 维。

完整结论（5 条）与局限性披露见 `report/surrogate_model_report.ipynb` 第 7 节。

---

## 3. 评估协议（四维）

由 `evaluator/surrogate_evaluator.py` 实现，每个模型同一协议：

| 维度 | 通过标准 |
|---|---|
| ① 最优 5% 局部精度 | 局部 MAE ≤ 1.5 × 整体 MAE；偏差 ≥ -3（不允许乐观低估好解） |
| ② 排名一致性 | Spearman ρ ≥ 0.6 |
| ③ 多模型最优解对比 | （报告内对比，不纳入判定） |
| ④ 子集模拟寻优 | 3 折 KFold，模型在每折 holdout 上挑 Top-10，真实分位 ≤ 10% 视为通过；通过率 ≥ 60% |

判定规则：4 项全过 → ✅ 推荐；过 3 项 → ⚠️ 基本可用；其余 → ❌ 不推荐。

---

## 4. 数据说明

- **train.csv**：2048 行 × 23 列。21 个特征是三栋楼 × 七项控制权重（每楼和为 1，成分数据），目标 `ramping` 是第 1–8 周平均净负荷相邻差绝对值之和（越小越好）。
- **无独立验证集**：所有评估均在这 2048 条上通过 CV 完成，跨周泛化不在本次评估范围。
- 详细字段定义与计算口径见 `data/README.md`。

---

## 5. 给复现/评估方的提示

1. **从 notebook 入手**——`report/surrogate_model_report.ipynb` 是自包含的：内置数据加载、特征工程、超参搜索、逐模型评估、对比表与可视化。重跑即可重现主结论。
2. **独立脚本仅作参考**——`models/*.py` 是各模型在历史开发阶段的单机版脚本，**口径与 notebook 略有差异**（划分比例、超参搜索范围）。结论以 notebook 为准。
3. **复现的注意点**：见 `REPRODUCE.md`，包含环境、固定种子、已知局限、常见坑。
4. **评估方任务**：建议先重跑 notebook，再用 `evaluator/surrogate_evaluator.py` 在同一协议下独立验证；对结论的合理性与局限性进行独立批判性评审（报告附录已自我披露 8 项局限）。

---

## 6. 已知局限（报告附录原文摘录）

- 超参在全量数据上用同一折分选择并评估，构成 selection–evaluation loop，OOF 误差是乐观估计。
- 单次折分、无重复 CV、无置信区间；<3% 差异不显著。
- 调参预算不一致（XGB/HistGB/SPMM/Ridge 在协议内调参，BART/GAM 沿用外部配置）。
- 最优 5% 区域仅 103 条样本，局部指标有统计波动。
- 评估器衡量"在已有候选池中挑好解"，不等价于真实环境控制器收益。
