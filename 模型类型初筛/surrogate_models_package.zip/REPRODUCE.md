# 复现步骤（给复现/评估方）

## 0. 环境

- Python 3.11（Anaconda / venv 均可）
- Windows / Linux / macOS 均可；开发机为 Windows 11 + Python 3.11

```bash
pip install -r requirements.txt
```

依赖核心版本（已在报告附录披露）：
- scikit-learn 1.6.1
- xgboost 3.4.1
- bartpy2 0.0.2

> **提示**：bartpy2 对 numpy 2.x 不兼容，requirements.txt 已固定 `numpy<2.0`。
> 若 numpy 被其他库强制升级，BART 会报错；其他模型不受影响。

## 1. 一键复现主结论（推荐路径）

主结论全部由 `report/surrogate_model_report.ipynb` 生成：

```bash
cd surrogate_models_package
jupyter nbconvert --to notebook --execute --inplace report/surrogate_model_report.ipynb
```

或在 Jupyter Lab / VSCode 中打开并 Run All。

**预期产物**：
- 控制台/单元格输出 9 个模型的 `report.summary()` 文本
- 对比表（与 `report/surrogate_eval_metrics.csv` 一致）
- 6 张可视化图（核心指标、OOF 拟合曲线、Top-3 详解）

**预期耗时**：普通桌面 CPU 约 8–15 分钟（BART 与 GAM 的 MCMC 占大头）。

## 2. 复现关键路径（精确还原 CSV）

若仅需复现 `surrogate_eval_metrics.csv` 中的数字，关注 notebook 的：

| Cell | 内容 | 作用 |
|---|---|---|
| [1] | 环境、路径与数据 | 固定 SEED=2026，加载 train.csv |
| [3] | 特征表示与模型组件 | 定义 RAW / ALR / CLR 变换器 |
| [4] | BART 与 SPMM | 包装非 sklearn 原生模型 |
| [6] | 统一 5 折 CV 与超参选择 | GridSearchCV 在同一折分上选超参 |
| [7] | 模型注册表 | 9 个 `make_xxx()` 工厂 |
| [9] | 逐模型评估 | 调用 `SurrogateEvaluator.evaluate` |
| [11] | 评估器原生对比表 | `compare_models` 输出 |
| [13] | 扩展对比表 | 写入 metrics_df（即 CSV 来源） |

## 3. 固定种子与统一折分

**整套报告只有 2 个种子**：

```python
SEED = 2026                                            # 全局
KFold(5, shuffle=True, random_state=2026)              # OOF / 超参搜索
KFold(3, shuffle=True, random_state=2026)              # 评估器内部子集寻优
```

修改任一种子都会改变结果。

## 4. 独立脚本运行（可选）

`models/*.py` 是历史开发脚本，与 notebook 协议略有差异：

```bash
# 示例：复现 XGBoost 原始 21 维
python models/xgb_regression_strat82.py

# 注意：脚本默认从当前工作目录读 dataset_same8/train.csv
# 请建立符号链接或修改脚本中的路径
ln -s ../data dataset_same8     # Linux/macOS
mklink /D dataset_same8 ..\data # Windows (管理员)
```

> **路径硬编码提醒**：部分脚本（如 `rf_regression_low50.py`、`spmm_regression.py`）通过
> `sys.path.insert(0, r"D:\...\Lab6")` 引入 `surrogate_evaluator.py`。
> 在您的环境中需改成 `evaluator/` 的相对/绝对路径。

## 5. 评估器单独使用

```python
import sys
sys.path.insert(0, "evaluator")
from surrogate_evaluator import SurrogateEvaluator

import pandas as pd
df = pd.read_csv("data/train.csv")
METRICS = ("cost","carbon","peak","discomfort","degradation","ramping","resilience")
FEATURES = [f"b{b}_{m}" for b in (1,2,3) for m in METRICS]
X = df[FEATURES].to_numpy()
y = df["ramping"].to_numpy()

ev = SurrogateEvaluator(X, y, feature_names=FEATURES)
report = ev.evaluate(
    trained_model,
    model_name="MyModel",
    oof_predictions=oof,           # 强烈建议传 OOF，否则偏乐观
    run_subset=True,
    model_factory=lambda: MyModel(**params),
    subset_folds=3,
    subset_topk=10,
)
print(report.summary())
```

## 6. 常见坑

1. **OOF 一定要传**：`evaluate()` 若不传 `oof_predictions`，会用 `model.predict(X)` 在训练集上预测，指标偏乐观。
2. **BART 评估时长**：MCMC 采样在 holdout 上要重新训练 3 次，比较耗时。
3. **GAM 的样本权重**：notebook 中 GAM 是通过自定义 Gibbs 采样实现的，与 pyGAM 接口不同，直接克隆到 `cross_val_predict` 会报错，需用 notebook 中的 `compute_oof` 手动逐折。
4. **评估器泄漏风险**：评估器内部 `subset_optimization` 重新做 KFold，对外部 `X, y` 闭包；与 OOF 折分**不同**，不要在两者间共享样本索引。

## 7. 验证已成功复现

复现完成后，比对以下数字（容差 ±0.5%）：

| 模型 | 整体 MAE | 最优 5% MAE | Spearman ρ |
|---|---|---|---|
| XGBoost (RAW) | 4.626 | 6.901 | 0.9073 |
| HistGB | 4.764 | 6.915 | 0.9008 |
| SPMM | 6.003 | 8.455 | 0.8567 |
| XGB + CLR | 5.402 | 9.603 | 0.8839 |
| RF (800) | 5.551 | 9.616 | 0.8675 |
| BART (50) | 6.693 | 12.969 | 0.8265 |
| XGB + ALR | 6.805 | 13.803 | 0.8060 |
| Ridge (deg=2) | 6.757 | 11.911 | 0.8419 |
| Bayesian GAM | 6.585 | 10.081 | 0.8378 |

完全匹配见 `report/surrogate_eval_metrics.csv`。

## 8. 评估方应该审视的问题

我们已在报告附录自我披露局限。建议评估方重点关注：

1. **selection–evaluation loop**：超参在与评估相同的 5 折上选择，OOF 是乐观估计，不能视为泛化性能。
2. **调参公平性**：BART/GAM/RF 的调参预算明显低于 XGB/HistGB/SPMM/Ridge。
3. **结论稳健性**：单次折分、无重复 CV，<3% 差异不显著。
4. **阈值敏感性**：判定阈值（1.5×、-3、0.6、10%）是评估器作者的工程经验，未做敏感性分析。
5. **寻优外推**：评估器衡量"在已有候选池中挑好解"，未衡量模型在连续寻优时的外推能力（ variants/xgb_conformal_strat82.py 是该方向的初步尝试）。
