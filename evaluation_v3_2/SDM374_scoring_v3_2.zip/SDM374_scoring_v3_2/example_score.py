"""Score one provided held-out prediction set; no fitting or new-W search."""
from pathlib import Path
import argparse
import json
from surrogate_scoring_v3_2 import load_final_policy,make_context,evaluate


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=Path(__file__).parent/'examples/input.json')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    data=json.loads(args.input.read_text(encoding='utf-8'))
    policy=load_final_policy()
    result=evaluate(data['actual'],data['predicted'],make_context(data['training_y'],policy),policy,data['candidate_ids'])
    text=json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
    if args.output:args.output.write_text(text,encoding='utf-8')
    else:print(text,end='')


if __name__=='__main__':main()
