"""Verify the standalone v3.2 package and its illustrated scoring behavior."""
from pathlib import Path
import hashlib
import json
import numpy as np
from surrogate_scoring_v3_2 import load_final_policy,make_context,evaluate

BASE=Path(__file__).resolve().parent


def main():
    checks=json.loads((BASE/'checksums.json').read_text(encoding='utf-8'))['files']
    release=json.loads((BASE/'RELEASE.json').read_text(encoding='utf-8'))
    assert set(checks)==set(release['files'])-{'checksums.json'}
    for name,expected in checks.items():
        path=(BASE/name).resolve()
        assert path.is_relative_to(BASE) and hashlib.sha256(path.read_bytes()).hexdigest()==expected,name
    for name,expected in release['source_sha256'].items():
        assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==expected,name
    data=json.loads((BASE/'examples/input.json').read_text(encoding='utf-8'))
    expected=json.loads((BASE/'examples/expected_output.json').read_text(encoding='utf-8'))
    policy=load_final_policy();context=make_context(data['training_y'],policy)
    y=np.array(data['actual']);p=np.array(data['predicted']);ids=np.array(data['candidate_ids'])
    result=evaluate(y,p,context,policy,ids)
    assert result==expected
    assert result['low_n']==4 and result['top1_regret']==.5
    np.testing.assert_allclose(result['points']['local_order'],35,atol=1e-10)
    np.testing.assert_allclose(result['points']['global_order'],15,atol=1e-10)
    np.testing.assert_allclose(result['points']['top1_regret'],20/(1+.5/context.scale))
    assert result['points']['top1_regret']<20
    np.testing.assert_allclose(result['points']['local_mae'],15/(1+.3/context.scale))
    np.testing.assert_allclose(result['points']['global_mae'],15/(1+(1.4/6)/context.scale))
    np.testing.assert_allclose(evaluate(y,y,context,policy,ids)['score'],100,atol=1e-10)
    shifted=evaluate(y,y+context.scale,context,policy,ids)
    np.testing.assert_allclose(shifted['points']['local_mae'],7.5)
    np.testing.assert_allclose(shifted['points']['global_mae'],7.5)
    assert shifted['top1_regret']==0
    tied=evaluate(y,np.zeros(len(y)),context,policy,ids)
    assert tied['top1_candidate_id']==str(min(ids))
    np.testing.assert_allclose(tied['points']['local_order'],0,atol=1e-10)
    assert tied==evaluate(y[::-1],np.zeros(len(y)),context,policy,ids[::-1])
    for bad_y,bad_p,bad_ids in [(np.array([140.,150.]),np.array([140.,150.]),['a','b']),
                               (y,p,['same']*len(y))]:
        try:evaluate(bad_y,bad_p,context,policy,bad_ids)
        except ValueError:pass
        else:raise AssertionError('Invalid evidence/IDs accepted')
    print(json.dumps(dict(status='passed',protocol_id=release['protocol_id'],files_verified=len(checks),
        example_reproduced=True,order_only_tolerance=True,mae_normalization=True,
        top1_tie_break=True,no_project_data_required=True),indent=2))


if __name__=='__main__':main()
